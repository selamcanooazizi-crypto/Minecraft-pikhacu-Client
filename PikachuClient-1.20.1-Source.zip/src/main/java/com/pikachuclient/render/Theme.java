package com.pikachuclient.render;

public final class Theme {
    public static final int ACCENT = 0xFFFFD83A;
    public static final int BLUE = 0xFF4DB8FF;
    public static final int BG = 0xF0121212;
    public static final int PANEL = 0xFF1A1A1A;
    public static final int ROW = 0xFF222222;
    public static final int ROW_HOVER = 0xFF2C2C2C;
    public static final int ROW_ON = 0xFF3A3210;
    public static final int SET_ROW = 0xFF181818;
    public static final int TEXT = 0xFFFFFFFF;
    public static final int DIM = 0xFF9A9A9A;
    private Theme() {}
}
