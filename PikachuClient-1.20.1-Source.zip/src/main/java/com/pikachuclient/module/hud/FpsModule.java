package com.pikachuclient.module.hud;

import net.minecraft.client.MinecraftClient;

/** Counts real rendered frames per second. */
public class FpsModule extends TextHudModule {
    private int frames, fps;
    private long windowStart = System.currentTimeMillis();

    public FpsModule() {
        super("fps", "FPS", "Shows your current frames per second.", 1, 1);
        enabled = true;
    }

    @Override
    protected String[] lines(MinecraftClient mc) {
        frames++;
        long now = System.currentTimeMillis();
        if (now - windowStart >= 1000) {
            fps = (int) Math.round(frames * 1000.0 / (now - windowStart));
            frames = 0;
            windowStart = now;
        }
        return new String[]{"FPS: " + fps};
    }
}
