package com.pikachuclient.module.hud;

import com.pikachuclient.PikachuClient;
import com.pikachuclient.module.Category;
import com.pikachuclient.module.Module;
import com.pikachuclient.module.setting.BooleanSetting;
import com.pikachuclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;

/** Base class for HUD elements. Positions are screen-relative percentages (0-100) and are saved in hud.json. */
public abstract class HudModule extends Module {
    protected final NumberSetting x, y, scale, opacity;
    protected final BooleanSetting background;
    private boolean failed;

    protected HudModule(String id, String name, String description, double defX, double defY) {
        super(id, name, Category.HUD, description);
        x = add(new NumberSetting("X position %", defX, 0, 100, 1, true));
        y = add(new NumberSetting("Y position %", defY, 0, 100, 1, true));
        scale = add(new NumberSetting("Scale", 1.0, 0.5, 3.0, 0.1, false));
        opacity = add(new NumberSetting("Background opacity %", 55, 0, 100, 5, true));
        background = add(new BooleanSetting("Background", true));
        x.markHud(); y.markHud(); scale.markHud(); opacity.markHud(); background.markHud();
    }

    /** @return {width, height} in unscaled pixels, or null to skip drawing this frame. */
    protected abstract int[] size(MinecraftClient mc);

    /** Draw at origin (0,0); translation and scale are already applied. */
    protected abstract void draw(DrawContext ctx, MinecraftClient mc);

    protected int bgColor() {
        int a = (int) Math.round(opacity.getValue() * 2.55);
        return (a << 24) | 0x101010;
    }

    public final void renderHud(DrawContext ctx, MinecraftClient mc) {
        try {
            int[] sz = size(mc);
            if (sz == null) return;
            float s = scale.floatValue();
            int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
            double px = (sw - sz[0] * s) * x.getValue() / 100.0;
            double py = (sh - sz[1] * s) * y.getValue() / 100.0;
            MatrixStack m = ctx.getMatrices();
            m.push();
            try {
                m.translate(px, py, 0.0);
                m.scale(s, s, 1.0f);
                draw(ctx, mc);
            } finally {
                m.pop();
            }
        } catch (Throwable t) {
            if (!failed) {
                failed = true;
                PikachuClient.LOGGER.error("HUD module '{}' failed to render", getId(), t);
            }
        }
    }
}
