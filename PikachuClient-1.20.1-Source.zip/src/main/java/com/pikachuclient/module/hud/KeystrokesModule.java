package com.pikachuclient.module.hud;

import com.pikachuclient.module.setting.NumberSetting;
import com.pikachuclient.render.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;

/** Shows real W/A/S/D/Space key state (uses the game's actual key bindings). */
public class KeystrokesModule extends HudModule {
    private final NumberSetting keySize = add(new NumberSetting("Key size", 20, 14, 40, 1, true));
    private final NumberSetting spacing = add(new NumberSetting("Spacing", 2, 0, 8, 1, true));

    public KeystrokesModule() {
        super("keystrokes", "Keystrokes", "Shows WASD and Space key states.", 1, 55);
    }

    @Override
    protected int[] size(MinecraftClient mc) {
        int ks = keySize.intValue(), sp = spacing.intValue();
        return new int[]{3 * ks + 2 * sp, 2 * ks + ks / 2 + 2 * sp};
    }

    @Override
    protected void draw(DrawContext ctx, MinecraftClient mc) {
        int ks = keySize.intValue(), sp = spacing.intValue();
        key(ctx, mc, "W", ks + sp, 0, ks, ks, mc.options.forwardKey);
        key(ctx, mc, "A", 0, ks + sp, ks, ks, mc.options.leftKey);
        key(ctx, mc, "S", ks + sp, ks + sp, ks, ks, mc.options.backKey);
        key(ctx, mc, "D", 2 * (ks + sp), ks + sp, ks, ks, mc.options.rightKey);
        key(ctx, mc, "Space", 0, 2 * (ks + sp), 3 * ks + 2 * sp, ks / 2, mc.options.jumpKey);
    }

    private void key(DrawContext ctx, MinecraftClient mc, String label, int x, int y, int w, int h, KeyBinding kb) {
        boolean down = kb.isPressed();
        int bg = down ? 0xE0FFD83A : bgColor();
        ctx.fill(x, y, x + w, y + h, bg);
        int tw = mc.textRenderer.getWidth(label);
        ctx.drawText(mc.textRenderer, label, x + (w - tw) / 2, y + (h - 8) / 2, down ? 0xFF000000 : Theme.TEXT, false);
    }
}
