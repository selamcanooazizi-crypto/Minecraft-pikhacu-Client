package com.pikachuclient.module.hud;

import com.pikachuclient.module.setting.BooleanSetting;
import com.pikachuclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Direction;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class CoordsModule extends TextHudModule {
    private final NumberSetting decimals = add(new NumberSetting("Decimals", 1, 0, 3, 1, true));
    private final BooleanSetting direction = add(new BooleanSetting("Show direction", true));
    private final BooleanSetting dimension = add(new BooleanSetting("Show dimension", true));

    public CoordsModule() {
        super("coords", "Coordinates", "Shows your real position, facing direction and dimension.", 1, 96);
        enabled = true;
    }

    @Override
    protected String[] lines(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) return null;
        String f = "%." + decimals.intValue() + "f";
        List<String> out = new ArrayList<>();
        out.add("XYZ: " + String.format(Locale.ROOT, f + " / " + f + " / " + f, mc.player.getX(), mc.player.getY(), mc.player.getZ()));
        if (direction.getValue()) {
            Direction d = mc.player.getHorizontalFacing();
            String n = d.asString();
            out.add("Facing: " + Character.toUpperCase(n.charAt(0)) + n.substring(1));
        }
        if (dimension.getValue()) out.add("Dimension: " + mc.world.getRegistryKey().getValue().getPath());
        return out.toArray(new String[0]);
    }
}
