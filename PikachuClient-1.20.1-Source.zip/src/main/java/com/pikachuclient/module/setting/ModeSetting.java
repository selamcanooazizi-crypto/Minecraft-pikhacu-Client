package com.pikachuclient.module.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class ModeSetting extends Setting<String> {
    private final String[] options;

    public ModeSetting(String name, String def, String... options) {
        super(name, def);
        this.options = options;
    }

    public int index() {
        for (int i = 0; i < options.length; i++) if (options[i].equals(value)) return i;
        return 0;
    }

    public void cycle() { value = options[(index() + 1) % options.length]; }

    @Override public JsonElement toJson() { return new JsonPrimitive(value); }

    @Override public void fromJson(JsonElement e) {
        if (e == null || !e.isJsonPrimitive() || !e.getAsJsonPrimitive().isString()) return;
        String s = e.getAsString();
        for (String o : options) if (o.equals(s)) { value = s; return; }
    }
}
