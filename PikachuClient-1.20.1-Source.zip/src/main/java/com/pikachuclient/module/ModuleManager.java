package com.pikachuclient.module;

import com.pikachuclient.module.hud.*;
import com.pikachuclient.module.movement.SprintModule;
import com.pikachuclient.module.render.FullbrightModule;
import com.pikachuclient.module.settings.NotificationsModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.InputUtil;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();
    private boolean started;

    public ModuleManager() {
        modules.add(new FpsModule());
        modules.add(new PingModule());
        modules.add(new CpsModule());
        modules.add(new CoordsModule());
        modules.add(new KeystrokesModule());
        modules.add(new ArmorModule());
        modules.add(new ClockModule());
        modules.add(new FullbrightModule());
        modules.add(new SprintModule());
        modules.add(new NotificationsModule());
    }

    public List<Module> all() { return modules; }

    public List<Module> byCategory(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : modules) if (m.getCategory() == c) out.add(m);
        return out;
    }

    public List<Category> categories() {
        List<Category> out = new ArrayList<>();
        for (Category c : Category.values()) if (!byCategory(c).isEmpty()) out.add(c);
        return out;
    }

    public Module findByKey(int key, Module except) {
        for (Module m : modules) if (m != except && m.getKey() == key) return m;
        return null;
    }

    public void tick(MinecraftClient mc) {
        if (!started) {
            started = true;
            for (Module m : modules) m.startIfEnabled();
        }
        if (mc.getWindow() != null && mc.currentScreen == null) {
            long handle = mc.getWindow().getHandle();
            for (Module m : modules) {
                if (m.getKey() <= 0) continue;
                boolean down = InputUtil.isKeyPressed(handle, m.getKey());
                if (down && !m.keyHeld) m.toggle();
                m.keyHeld = down;
            }
        }
        for (Module m : modules) if (m.isEnabled()) m.tickSafe(mc);
    }

    public void renderHud(DrawContext ctx, MinecraftClient mc) {
        for (Module m : modules) {
            if (m.isEnabled() && m instanceof HudModule h) h.renderHud(ctx, mc);
        }
    }

    public void shutdown() {
        for (Module m : modules) m.stopIfEnabled();
    }
}
