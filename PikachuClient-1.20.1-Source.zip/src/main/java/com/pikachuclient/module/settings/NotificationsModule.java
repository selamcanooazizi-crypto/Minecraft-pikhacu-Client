package com.pikachuclient.module.settings;

import com.pikachuclient.PikachuClient;
import com.pikachuclient.module.Category;
import com.pikachuclient.module.Module;
import com.pikachuclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;

public class NotificationsModule extends Module {
    private final NumberSetting duration = add(new NumberSetting("Duration (s)", 3, 1, 10, 0.5, false));

    public NotificationsModule() {
        super("notifications", "Notifications", Category.SETTINGS, "Slide-in notifications for module toggles and config events.");
        enabled = true;
    }

    @Override protected void onEnable() { PikachuClient.notifications().setEnabled(true); }
    @Override protected void onDisable() { PikachuClient.notifications().setEnabled(false); }
    @Override protected void onTick(MinecraftClient mc) { PikachuClient.notifications().setDuration(duration.getValue()); }
}
