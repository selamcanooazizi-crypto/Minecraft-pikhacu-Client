package com.pikachuclient.module.movement;

import com.pikachuclient.module.Category;
import com.pikachuclient.module.Module;
import net.minecraft.client.MinecraftClient;

/** Convenience: holds sprint while you move forward, using normal vanilla sprint rules. */
public class SprintModule extends Module {
    public SprintModule() {
        super("sprint", "Always Sprint", Category.MOVEMENT, "Sprints automatically while moving forward (vanilla rules).");
    }

    @Override
    protected void onTick(MinecraftClient mc) {
        if (mc.player == null) return;
        boolean canSprint = mc.player.getHungerManager().getFoodLevel() > 6 || mc.player.getAbilities().allowFlying;
        if (canSprint && mc.player.input.movementForward > 0 && !mc.player.isSneaking()
                && !mc.player.horizontalCollision && !mc.player.isUsingItem()) {
            mc.player.setSprinting(true);
        }
    }
}
