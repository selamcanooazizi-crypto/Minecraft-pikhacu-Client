package com.pikachuclient.notification;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class NotificationManager {
    private static final class Note {
        final String text;
        long shownAt = -1;
        Note(String t) { text = t; }
    }

    private final List<Note> notes = new ArrayList<>();
    private volatile boolean enabled = true;
    private volatile double durationSec = 3.0;

    public void setEnabled(boolean e) { enabled = e; }
    public void setDuration(double s) { durationSec = s; }

    public synchronized void push(String text) {
        if (!enabled) return;
        if (notes.size() >= 5) notes.remove(0);
        notes.add(new Note(text));
    }

    public synchronized void render(DrawContext ctx, MinecraftClient mc) {
        if (notes.isEmpty()) return;
        long now = System.currentTimeMillis();
        long life = (long) (durationSec * 1000);
        int sw = ctx.getScaledWindowWidth();
        int y = 6;
        Iterator<Note> it = notes.iterator();
        while (it.hasNext()) {
            Note n = it.next();
            if (n.shownAt < 0) n.shownAt = now;
            long age = now - n.shownAt;
            if (age > life) { it.remove(); continue; }
            int w = mc.textRenderer.getWidth(n.text) + 16;
            float in = Math.min(1f, age / 250f);
            float out = Math.min(1f, (life - age) / 250f);
            float k = Math.min(in, out);
            k = 1f - (1f - k) * (1f - k);
            int x = (int) (sw - (w + 6) * k);
            ctx.fill(x, y, x + w, y + 18, 0xE0121212);
            ctx.fill(x, y, x + 2, y + 18, 0xFFFFD83A);
            ctx.drawText(mc.textRenderer, n.text, x + 8, y + 5, 0xFFFFFFFF, true);
            y += 22;
        }
    }
}
