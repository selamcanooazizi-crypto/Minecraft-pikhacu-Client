package com.pikachuclient;

import com.pikachuclient.config.ConfigManager;
import com.pikachuclient.gui.clickgui.ClickGuiScreen;
import com.pikachuclient.module.ModuleManager;
import com.pikachuclient.notification.NotificationManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PikachuClient implements ClientModInitializer {
    public static final String MOD_ID = "pikachuclient";
    public static final Logger LOGGER = LoggerFactory.getLogger("PikachuClient");

    private static ModuleManager modules;
    private static ConfigManager config;
    private static NotificationManager notifications;
    private static KeyBinding guiKey;

    public static ModuleManager modules() { return modules; }
    public static ConfigManager config() { return config; }
    public static NotificationManager notifications() { return notifications; }
    public static KeyBinding guiKey() { return guiKey; }

    @Override
    public void onInitializeClient() {
        notifications = new NotificationManager();
        modules = new ModuleManager();
        config = new ConfigManager(modules);
        config.load();

        guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.pikachuclient.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.pikachuclient"));

        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
        HudRenderCallback.EVENT.register(this::onHud);
        ClientLifecycleEvents.CLIENT_STOPPING.register(c -> {
            config.save();
            modules.shutdown();
        });
        LOGGER.info("Pikachu Client loaded.");
    }

    private void onTick(MinecraftClient client) {
        modules.tick(client);
        while (guiKey.wasPressed()) {
            if (client.currentScreen == null) client.setScreen(new ClickGuiScreen());
        }
    }

    private void onHud(DrawContext ctx, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden) return;
        modules.renderHud(ctx, mc);
        notifications.render(ctx, mc);
    }
}
