# Pikachu Client (Aşama 1) — Minecraft 1.20.1 Fabric

Yalnızca istemci tarafı (client-side) bir Fabric modu. Java 17 gerekir.

## JAR'ı GitHub ile derleme
1. zip'i bilgisayarda/telefonda **çıkar**.
2. GitHub'da yeni bir repo aç ve çıkan klasörün **içindekileri** yükle (`.github` klasörü dahil, gizli klasör olduğuna dikkat et).
   Yükleme zorsa `git push` kullan.
3. Repo → **Actions** sekmesi → "Build PikachuClient" çalışır (yoksa *Run workflow*).
4. Bitince çalıştırmanın altındaki **Artifacts** bölümünden `PikachuClient-1.20.1` dosyasını indir; içinden `PikachuClient-1.20.1.jar` çıkar.

Bilgisayarda: `gradle build` (Gradle 8.5+, JDK 17) → `build/libs/PikachuClient-1.20.1.jar`

## Kurulum (ZalithLauncher / PojavLauncher / PC)
1. Minecraft 1.20.1 için Fabric Loader kur (0.15.x önerilir).
2. Java 17 seçili olsun.
3. Fabric API 0.92.2+1.20.1 JAR'ını `mods` klasörüne koy.
4. `PikachuClient-1.20.1.jar` dosyasını da `mods` klasörüne koy.
5. Oyunu aç, **Sağ Shift** ile Click GUI'yi aç (Kontroller'den değiştirilebilir).

## Ayar dosyaları
`.minecraft/config/pikachuclient/` içinde: `config.json`, `hud.json`, `keybinds.json`, `profiles/`

## Mevcut modüller
HUD: FPS, Ping, CPS, Coordinates (+yön/dimension), Keystrokes (WASD+Space), Armor Status, Clock
Render: Fullbright (yalnızca görsel, istemci tarafı)
Movement: Always Sprint
Settings: Notifications

## Henüz yok (sonraki aşamalar)
HUD editörü (sürükle-bırak; şimdilik konum/ölçek GUI'deki kaydırıcılarla ayarlanır), profil sistemi/arayüzü,
özel ana menü, arama/favoriler, crosshair özelleştirme, Zoom/Freelook, potion HUD, animasyonlar, ses.

## Önemli not
Bu proje yazıldığı ortamda derlenmedi ve test edilmedi. İlk derlemede küçük hatalar çıkabilir;
Android uyumluluğu test edilmedi.
